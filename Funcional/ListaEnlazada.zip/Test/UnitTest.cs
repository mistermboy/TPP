﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ListaEnlazadaSesion01
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestAñadirPrincipio()
        {
            LinkedList lista = new LinkedList();

            Assert.AreEqual(0, lista.NumElementos);

            lista.AñadirFinal(55);
            lista.AñadirFinal(32);
            lista.AñadirFinal(69);
            lista.AñadirFinal(97);
            lista.AñadirFinal(37);
            lista.AñadirFinal(11);
            lista.AñadirFinal(13);

            Assert.AreEqual(7, lista.NumElementos);

            lista.AñadirPrincipio(5);
            Assert.AreEqual(8, lista.NumElementos);
            Assert.AreEqual(5, lista.GetElementoPrimero());
        }

        [TestMethod]
        public void TestBorrar()
        {
            LinkedList lista = new LinkedList();

            Assert.AreEqual(0, lista.NumElementos);

            lista.AñadirFinal(55);
            lista.AñadirFinal(32);
            lista.AñadirFinal(69);
            lista.AñadirFinal(97);
            lista.AñadirFinal(37);
            lista.AñadirFinal(11);
            lista.AñadirFinal(13);

            Assert.AreEqual(7, lista.NumElementos);

            lista.Borrar(5);
            Assert.AreEqual(6, lista.NumElementos);
            Assert.AreEqual(13, lista.GetElemento(5));
        }
        [TestMethod]
        public void TestContiene()
        {
            LinkedList lista = new LinkedList();

            Assert.AreEqual(0, lista.NumElementos);

            lista.AñadirFinal(55);
            lista.AñadirFinal(32);
            lista.AñadirFinal(69);
            lista.AñadirFinal(97);
            lista.AñadirFinal(37);
            lista.AñadirFinal(11);
            lista.AñadirFinal(13);

            Assert.AreEqual(7, lista.NumElementos);

            Assert.IsTrue(lista.Contiene(32));
        }

        [TestMethod]
        public void TestPush()
        {
            Pila pila = new Pila(10);

            Assert.IsTrue(pila.estaVacia);

            for (int i = 0; i < 10; i++)
            {
                pila.Push(i);
            }
            Assert.IsTrue(pila.estaLlena);

            try
            {
                pila.Push(11);
                Assert.Fail();
            }
            catch (InvalidOperationException) { }
        }

        [TestMethod]
        public void TestPop()
        {
            Pila pila = new Pila(10);

            Assert.IsTrue(pila.estaVacia);
            Assert.IsFalse(pila.estaLlena);

            try
            {
                pila.Pop();
                Assert.Fail();
            }
            catch (InvalidOperationException) { }

            for (int i = 0; i < 10; i++)
            {
                pila.Push(i);
            }
            Assert.IsTrue(pila.estaLlena);

            pila.Pop();
           
            for (int i = 0; i < 9; i++)
            {
                pila.Pop();
            }
            Assert.IsTrue(pila.estaVacia);
        }
    }
}
