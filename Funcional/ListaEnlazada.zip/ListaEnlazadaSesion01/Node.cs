﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaEnlazadaSesion01
{
    public class Node
    {
        public Node Siguiente { get; set; }
        public Object Info { get; set; }
    }
}
